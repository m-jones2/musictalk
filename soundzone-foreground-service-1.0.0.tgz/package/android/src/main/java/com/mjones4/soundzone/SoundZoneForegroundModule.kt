package com.mjones4.soundzone

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class SoundZoneForegroundModule : Module() {
    override fun definition() = ModuleDefinition {
        Name("SoundZoneForeground")

        AsyncFunction("startService") { roomCode: String, heartbeatUrl: String, userId: String ->
            val context = appContext.reactContext?.applicationContext
                ?: throw Exception("React context not available")

            val audioPermission = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            )
            if (audioPermission != PackageManager.PERMISSION_GRANTED) {
                throw Exception("RECORD_AUDIO permission not granted")
            }

            val intent = Intent(context, SoundZoneForegroundService::class.java).apply {
                action = SoundZoneForegroundService.ACTION_START
                putExtra(SoundZoneForegroundService.EXTRA_ROOM_CODE, roomCode)
                putExtra(SoundZoneForegroundService.EXTRA_HEARTBEAT_URL, heartbeatUrl)
                putExtra(SoundZoneForegroundService.EXTRA_USER_ID, userId)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Unit
        }

        AsyncFunction("updateService") { roomCode: String ->
            val context = appContext.reactContext?.applicationContext
                ?: throw Exception("React context not available")

            val intent = Intent(context, SoundZoneForegroundService::class.java).apply {
                action = SoundZoneForegroundService.ACTION_UPDATE
                putExtra(SoundZoneForegroundService.EXTRA_ROOM_CODE, roomCode)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Unit
        }

        AsyncFunction("stopService") {
            val context = appContext.reactContext?.applicationContext
                ?: throw Exception("React context not available")

            val intent = Intent(context, SoundZoneForegroundService::class.java).apply {
                action = SoundZoneForegroundService.ACTION_STOP
            }
            context.startService(intent)
        }

        Function("isRunning") {
            SoundZoneForegroundService.isRunning
        }
    }
}